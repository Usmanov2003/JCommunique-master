package com.platform;

public interface OperatingSystem {
	public boolean isSupported(String feature);
}
