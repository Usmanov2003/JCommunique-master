package com.theme;

import java.awt.Color;
import java.awt.Font;

public class TextTheme {
	public Font title;
	public Font subtitle;
	public Color titleColor;
	public Color subtitleColor;
}
