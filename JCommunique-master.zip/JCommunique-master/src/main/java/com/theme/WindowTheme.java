package com.theme;

import java.awt.Color;

public class WindowTheme {
	public Color background;
	public Color foreground;
	public double opacity;
	public int width;
	public int height;
}
