package com.unit;

public class TestUtils {
	public static final double TINY_DELTA = 0.000000001;
}
